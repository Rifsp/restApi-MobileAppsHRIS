from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBearer,
)
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.auth import (
    CurrentUserData,
    CurrentUserResponse,
    LoginData,
    LoginRequest,
    LoginResponse,
    UserResponse,
)
from app.security import (
    create_access_token,
    decode_access_token,
    verify_legacy_password,
)


bearer_scheme = HTTPBearer(auto_error=False)

router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"],
)


def get_active_employee(
    db: Session,
    user_id: int,
):
    employees = db.execute(
        text(
            """
            SELECT
                k.i_karyawan,
                k.i_user,
                k.i_company,
                k.e_nik,
                k.e_karyawan_name,
                k.e_tipe_karyawan,
                k.f_wajib_lokasi,
                k.i_jadwal,
                k.i_lokasi_absen,
                k.f_aktif,
                COALESCE(
                    k.e_timezone,
                    'Asia/Jakarta'
                ) AS e_timezone,
                c.e_company_name
            FROM public.tr_hr_karyawan k
            INNER JOIN public.tr_company c
                ON c.i_company = k.i_company
            WHERE k.i_user = :user_id
              AND k.f_aktif = TRUE
            ORDER BY k.i_company
            """
        ),
        {
            "user_id": user_id,
        },
    ).mappings().all()

    if len(employees) == 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Akun belum terdaftar sebagai "
                "karyawan aktif."
            ),
        )

    if len(employees) > 1:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Akun memiliki lebih dari satu data "
                "karyawan aktif. Hubungi MIS."
            ),
        )

    return employees[0]


def make_user_response(
    user,
    employee,
) -> UserResponse:
    return UserResponse(
        i_user=user["i_user"],
        i_karyawan=employee["i_karyawan"],
        i_user_id=user["i_user_id"],
        e_user_name=user["e_user_name"],
        e_karyawan_name=(
            employee["e_karyawan_name"]
            or user["e_user_name"]
        ),
        f_pusat=user["f_pusat"],
        ava=user["ava"],
        i_company=employee["i_company"],
        e_company_name=employee["e_company_name"],
        e_nik=employee["e_nik"],
        e_tipe_karyawan=employee["e_tipe_karyawan"],
        f_wajib_lokasi=(
            employee["f_wajib_lokasi"] is True
        ),
        i_jadwal=employee["i_jadwal"],
        i_lokasi_absen=employee["i_lokasi_absen"],
        e_timezone=employee["e_timezone"],
    )


@router.post(
    "/login",
    response_model=LoginResponse,
)
def login(
    request: LoginRequest,
    db: Session = Depends(get_db),
):
    username = request.username.strip()
    password = request.password.strip()

    invalid_login = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Username atau password salah.",
        headers={
            "WWW-Authenticate": "Bearer",
        },
    )

    user = db.execute(
        text(
            """
            SELECT
                i_user,
                i_user_id,
                e_user_password,
                e_user_name,
                f_status,
                f_pusat,
                ava
            FROM public.tm_user
            WHERE i_user_id = :username
            LIMIT 1
            """
        ),
        {
            "username": username,
        },
    ).mappings().first()

    if user is None:
        raise invalid_login

    if not verify_legacy_password(
        password,
        user["e_user_password"],
    ):
        raise invalid_login

    employee = get_active_employee(
        db=db,
        user_id=user["i_user"],
    )

    access_token, expires_in = create_access_token(
        subject=str(user["i_user"]),
        additional_claims={
            "username": user["i_user_id"],
            "name": user["e_user_name"],
            "i_company": employee["i_company"],
        },
    )

    return LoginResponse(
        status=True,
        message="Login berhasil.",
        data=LoginData(
            access_token=access_token,
            expires_in=expires_in,
            user=make_user_response(
                user=user,
                employee=employee,
            ),
        ),
    )


@router.get(
    "/me",
    response_model=CurrentUserResponse,
)
def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    ),
    db: Session = Depends(get_db),
):
    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Sesi tidak valid atau sudah berakhir.",
        headers={
            "WWW-Authenticate": "Bearer",
        },
    )

    if credentials is None:
        raise unauthorized

    if credentials.scheme.lower() != "bearer":
        raise unauthorized

    payload = decode_access_token(
        credentials.credentials
    )

    if payload is None:
        raise unauthorized

    try:
        user_id = int(payload["sub"])
        token_company = int(payload["i_company"])
    except (KeyError, TypeError, ValueError):
        raise unauthorized

    user = db.execute(
        text(
            """
            SELECT
                i_user,
                i_user_id,
                e_user_name,
                f_status,
                f_pusat,
                ava
            FROM public.tm_user
            WHERE i_user = :user_id
            LIMIT 1
            """
        ),
        {
            "user_id": user_id,
        },
    ).mappings().first()

    if user is None:
        raise unauthorized

    employee = get_active_employee(
        db=db,
        user_id=user_id,
    )

    # Jika perusahaan karyawan berubah, token lama
    # harus dibuang dan pengguna login kembali. 
    if employee["i_company"] != token_company:
        raise unauthorized

    return CurrentUserResponse(
        status=True,
        message="Sesi pengguna valid.",
        data=CurrentUserData(
            user=make_user_response(
                user=user,
                employee=employee,
            )
        ),
    )
